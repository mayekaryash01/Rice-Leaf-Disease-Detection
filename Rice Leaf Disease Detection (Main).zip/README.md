# 🌾 Paddy Leaf Disease Classifier

A deep learning-powered web application for detecting common rice (paddy) leaf diseases from imagery using transfer learning with EfficientNet-B3. The system provides disease-specific agronomic diagnosis and actionable treatment guidance to support farmers and agricultural professionals.

---

## Overview

Rice is a vital global staple crop, yet timely disease diagnosis often requires expert plant pathology knowledge that may not be immediately available in field conditions. This project makes rapid disease identification accessible through computer vision and deep learning.

Users simply upload a photo of a rice leaf, and the application:

* Preprocesses and evaluates the leaf image using a trained PyTorch model
* Classifies the condition with statistical confidence scores
* Outlines immediate cultural management and targeted chemical treatment guides
* Delivers results through a clean, responsive Streamlit interface

---

## Features

* 🌿 Rice leaf disease classification using **EfficientNet-B3**
* 📷 Intuitive drag-and-drop image upload interface
* 🩺 Disease-specific agronomic management and fungicide/pesticide guides
* ⚡ Fast inference with model caching
* 📊 Real-time class probability and confidence breakdown
* 💻 Lightweight and easy to run locally or in the cloud

---

## Model Information

| Item | Details |
| :--- | :--- |
| **Architecture** | EfficientNet-B3 |
| **Framework** | PyTorch & Torchvision |
| **Training Strategy** | Transfer Learning & Fine-Tuning |
| **Input Resolution** | 300 × 300 pixels |
| **Number of Classes** | 4 |

### Supported Conditions

| Class Identifier | Condition Name | Description |
| :--- | :--- | :--- |
| `bacterial_leaf_blight` | **Bacterial Leaf Blight** | Bacterial vascular infection causing longitudinal wavy lesions |
| `brown_spot` | **Brown Spot Disease** | Fungal disease associated with nutrient deficiencies |
| `tungro` | **Tungro Virus Disease** | Viral disease transmitted by leafhopper insect vectors |
| `normal` | **Healthy Rice Leaf** | Clean leaf blade showing no disease symptoms |

---

## Tech Stack

* **Python**
* **PyTorch** & **Torchvision**
* **FastAPI** & **Uvicorn**
* **Scikit-learn**
* **Pillow**
* **Joblib**

---

## Project Structure

```text
.
├── app.py                       # Main web application & API
├── efficientnetb3model3.pth     # Trained PyTorch model weights
├── label_encoder3.pkl           # Scikit-learn label encoder
├── requirements.txt             # Python dependencies
├── run.bat                      # 1-click Windows launcher
└── README.md                    # Project documentation
```

---

## Getting Started

### 1. Set Up a Virtual Environment (Optional)

```bash
python -m venv .venv
```

**Windows:**
```bash
.venv\Scripts\activate
```

**Linux / macOS:**
```bash
source .venv/bin/activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Launch the Application

```bash
python app.py
```
*(On Windows, you can simply double-click **run.bat**)*

The application will start immediately at `http://localhost:8501`.

---

## License

This project is intended for educational, research, and agronomic diagnostic purposes.
